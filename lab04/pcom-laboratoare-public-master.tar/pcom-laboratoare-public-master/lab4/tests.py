HOSTS = [ 0, 1, 2, 3 ]

TESTS = {
        'ping': { 'hosts_p': HOSTS, 'hosts_a': HOSTS },
        'ping6': { 'hosts_p': HOSTS, 'hosts_a': HOSTS }
}
