#include "common.h"

uint16_t inet_csum(uint8_t *buf, size_t len) {
	//TODO1: Calculate the internet checksum according to RFC1071
}
